<?php
session_start();
include "db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["is_admin"] != 1) {
    header("Location: login.php");
    exit();
}

$sql = "SELECT bookings.*, users.name, users.email FROM bookings
        JOIN users ON bookings.user_id = users.id
        ORDER BY bookings.id DESC";
$result = mysqli_query($conn, $sql);
?>

<html>
<head>
    <title>Admin Panel</title>
</head>
<body>

<h2>All Bookings (Admin)</h2>

<p><a href="logout.php">Logout</a></p>

<table border="1">
<tr>
    <th>ID</th>
    <th>User Name</th>
    <th>Email</th>
    <th>Flight</th>
    <th>From</th>
    <th>To</th>
    <th>Departure Date</th>
    <th>Booking Date</th>
    <th>Passport Photo</th>
</tr>

<?php while ($row = mysqli_fetch_assoc($result)) { ?>
<tr>
    <td><?php echo $row["id"]; ?></td>
    <td><?php echo $row["name"]; ?></td>
    <td><?php echo $row["email"]; ?></td>
    <td><?php echo $row["flight_name"]; ?></td>
    <td><?php echo $row["departure_city"]; ?></td>
    <td><?php echo $row["arrival_city"]; ?></td>
    <td><?php echo $row["departure_date"]; ?></td>
    <td><?php echo $row["booking_date"]; ?></td>
    <td>
        <?php if ($row["passport_photo"] != "") { ?>
            <img src="uploads/<?php echo $row["passport_photo"]; ?>" width="80">
        <?php } else { ?>
            No Photo
        <?php } ?>
    </td>
</tr>
<?php } ?>

</table>

</body>
</html>
