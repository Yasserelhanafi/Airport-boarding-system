CREATE DATABASE airport_system;

USE airport_system;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(50) NOT NULL,
    is_admin INT DEFAULT 0
);

CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    flight_name VARCHAR(50) NOT NULL,
    departure_city VARCHAR(50) NOT NULL,
    arrival_city VARCHAR(50) NOT NULL,
    departure_date DATE NOT NULL,
    booking_date DATETIME NOT NULL,
    passport_photo VARCHAR(100),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

INSERT INTO users (name, email, password, is_admin)
VALUES ('Admin User', 'admin@airport.com', 'admin123', 1);

INSERT INTO users (name, email, password, is_admin)
VALUES ('John Student', 'john@airport.com', 'john123', 0);
