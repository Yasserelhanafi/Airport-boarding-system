Airport Boarding Pass System - Setup Instructions

1. Install XAMPP (or any server with PHP + MySQL).
2. Copy this whole folder into htdocs (e.g. C:\xampp\htdocs\airport_boarding_system).
3. Start Apache and MySQL from the XAMPP control panel.
4. Open phpMyAdmin (http://localhost/phpmyadmin).
5. Import airport_system.sql to create the database and tables.
6. Make sure the "uploads" folder exists inside the project and is writable.
7. Open http://localhost/airport_boarding_system/register.php to create a user account.
8. Login using login.php.
9. Use book.php to book a flight and upload a passport photo.
10. View your bookings in dashboard.php.

Admin Login:
Email: admin@airport.com
Password: admin123

Admin can view all bookings and uploaded photos in admin.php.

Files:
- db.php        : database connection
- register.php  : user registration
- login.php     : user login with remember me cookie
- logout.php    : destroys session and cookies
- dashboard.php : shows logged in user's bookings
- book.php      : book a flight and upload passport photo
- admin.php     : admin view of all bookings
- airport_system.sql : database script
- uploads/      : folder where passport photos are stored
