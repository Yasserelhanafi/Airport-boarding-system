<?php
session_start();
include "db.php";

if (isset($_COOKIE["remember_email"]) && isset($_COOKIE["remember_password"])) {
    $email = $_COOKIE["remember_email"];
    $password = $_COOKIE["remember_password"];

    $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["name"] = $user["name"];
        $_SESSION["is_admin"] = $user["is_admin"];

        if ($user["is_admin"] == 1) {
            header("Location: admin.php");
        } else {
            header("Location: dashboard.php");
        }
        exit();
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["name"] = $user["name"];
        $_SESSION["is_admin"] = $user["is_admin"];

        if (isset($_POST["remember"])) {
            setcookie("remember_email", $email, time() + (86400 * 7));
            setcookie("remember_password", $password, time() + (86400 * 7));
        }

        if ($user["is_admin"] == 1) {
            header("Location: admin.php");
        } else {
            header("Location: dashboard.php");
        }
        exit();
    } else {
        echo "Invalid email or password";
    }
}
?>

<html>
<head>
    <title>Login</title>
</head>
<body>

<h2>Login</h2>

<form method="post" action="login.php">
    Email: <input type="email" name="email" required><br><br>
    Password: <input type="password" name="password" required><br><br>
    Remember Me: <input type="checkbox" name="remember"><br><br>
    <input type="submit" value="Login">
</form>

<p>Don't have an account? <a href="register.php">Register here</a></p>

</body>
</html>
