<?php
session_start();
include "db.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

$sql = "SELECT * FROM bookings WHERE user_id = $user_id";
$result = mysqli_query($conn, $sql);
?>

<html>
<head>
    <title>Dashboard</title>
</head>
<body>

<h2>Welcome, <?php echo $_SESSION["name"]; ?></h2>

<p><a href="book.php">Book a Flight</a> | <a href="logout.php">Logout</a></p>

<h3>Your Bookings</h3>

<table border="1">
<tr>
    <th>ID</th>
    <th>Flight</th>
    <th>From</th>
    <th>To</th>
    <th>Departure Date</th>
    <th>Booking Date</th>
    <th>Passport Photo</th>
</tr>

<?php while ($row = mysqli_fetch_assoc($result)) { ?>
<tr>
    <td><?php echo $row["id"]; ?></td>
    <td><?php echo $row["flight_name"]; ?></td>
    <td><?php echo $row["departure_city"]; ?></td>
    <td><?php echo $row["arrival_city"]; ?></td>
    <td><?php echo $row["departure_date"]; ?></td>
    <td><?php echo $row["booking_date"]; ?></td>
    <td>
        <?php if ($row["passport_photo"] != "") { ?>
            <img src="uploads/<?php echo $row["passport_photo"]; ?>" width="80">
        <?php } else { ?>
            No Photo
        <?php } ?>
    </td>
</tr>
<?php } ?>

</table>

</body>
</html>
