<?php
session_start();
include "db.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $flight_name = $_POST["flight_name"];
    $departure_city = $_POST["departure_city"];
    $arrival_city = $_POST["arrival_city"];
    $departure_date = $_POST["departure_date"];
    $booking_date = date("Y-m-d H:i:s");

    $photo_name = "";

    if ($_FILES["passport_photo"]["name"] != "") {
        $file_name = $_FILES["passport_photo"]["name"];
        $file_tmp = $_FILES["passport_photo"]["tmp_name"];
        $ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if ($ext == "jpg" || $ext == "jpeg" || $ext == "png") {
            $photo_name = time() . "_" . $file_name;
            move_uploaded_file($file_tmp, "uploads/" . $photo_name);
        } else {
            echo "Invalid file type. Only jpg, jpeg, png allowed.<br>";
        }
    }

    $sql = "INSERT INTO bookings (user_id, flight_name, departure_city, arrival_city, departure_date, booking_date, passport_photo)
            VALUES ($user_id, '$flight_name', '$departure_city', '$arrival_city', '$departure_date', '$booking_date', '$photo_name')";

    if (mysqli_query($conn, $sql)) {
        echo "Booking successful. <a href='dashboard.php'>Go to Dashboard</a>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<html>
<head>
    <title>Book a Flight</title>
</head>
<body>

<h2>Book a Flight</h2>

<form method="post" action="book.php" enctype="multipart/form-data">
    Flight Name: <input type="text" name="flight_name" required><br><br>
    Departure City: <input type="text" name="departure_city" required><br><br>
    Arrival City: <input type="text" name="arrival_city" required><br><br>
    Departure Date: <input type="date" name="departure_date" required><br><br>
    Passport Photo: <input type="file" name="passport_photo" required><br><br>
    <input type="submit" value="Book Flight">
</form>

<p><a href="dashboard.php">Back to Dashboard</a></p>

</body>
</html>
